Spremite skinuti active_configfile iz routera ovdje i pokrenite decrypt.bat kako bi se generirao decrypted_configfile.

---------------------------------------------------------------------------------------------------------------------------

Place downloaded active_configfile from router to this folder and run decrypt.bat in order do generate decrypted_configfile.